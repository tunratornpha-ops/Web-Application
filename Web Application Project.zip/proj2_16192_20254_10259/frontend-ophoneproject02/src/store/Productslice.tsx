// นำเข้าเครื่องมือจาก Redux Toolkit
import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
import api from '../api/axiosConfig'; // ใช้ axios instance ที่ตั้ง baseURL '/api'

//  ดึงข้อมูลสินค้าทั้งหมดจาก backend (GET /api/products)
export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
    const res = await api.get('/products');
    return res.data; // ส่งข้อมูลสินค้ามาเก็บใน state
});

//  ดึงข้อมูลสินค้าเฉพาะตัว (GET /api/products/:id)
export const fetchProductById = createAsyncThunk(
    'products/fetchById',
    async (id: string) => {
        const res = await api.get(`/products/${id}`);
        return res.data;
    }
);

//  ส่งคำสั่งซื้อใหม่ไป backend (POST /api/orders)
export const createOrder = createAsyncThunk('products/createOrder', async (order: Order) => {
    const res = await api.post('/orders', order);
    return res.data;
});

// 🧩 โครงสร้างข้อมูลสินค้า
interface Product {
    id?: string;
    name: string;
    price: number;
    colorOptions?: string[];
    storageOptions?: string[];
    quantity?: number;
    status: string;
}

//  โครงสร้างคำสั่งซื้อ
interface Order {
    id?: string;
    name: string;
    price: number;
    color: string;
}

//  โครงสร้าง state ของ slice
interface ProductState {
    items: Product[];
    selectedModel: string | null;
    selectedColor: string | null;
    loading: boolean;
    error: string | null;
    successMessage: string | null;
}

//  ค่าตั้งต้นของ state
const initialState: ProductState = {
    items: [],
    selectedModel: null,
    selectedColor: null,
    loading: false,
    error: null,
    successMessage: null,
};

//  สร้าง slice สำหรับสินค้า
const productSlice = createSlice({
    name: 'products',
    initialState,
    reducers: {
        //  เก็บรุ่นที่เลือก (เช่น OPhone 15)
        setSelectedModel: (state, action: PayloadAction<string>) => {
            state.selectedModel = action.payload;
        },
        //  เก็บสีที่เลือก
        setSelectedColor: (state, action: PayloadAction<string>) => {
            state.selectedColor = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            //  โหลดสินค้าทั้งหมด
            .addCase(fetchProducts.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchProducts.fulfilled, (state, action: PayloadAction<Product[]>) => {
                state.loading = false;
                state.items = action.payload;
            })
            .addCase(fetchProducts.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || 'โหลดข้อมูลสินค้าทั้งหมดไม่สำเร็จ ❌';
            })

            //  โหลดสินค้าตาม ID
            .addCase(fetchProductById.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchProductById.fulfilled, (state, action: PayloadAction<Product>) => {
                state.loading = false;
                //  ถ้ามีสินค้าอยู่แล้วให้แทนตัวนั้น ถ้าไม่มีให้เพิ่มใหม่
                const existing = state.items.find((p) => p.id === action.payload.id);
                if (!existing) state.items.push(action.payload);
            })
            .addCase(fetchProductById.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message || 'โหลดข้อมูลสินค้าไม่สำเร็จ ❌';
            })

            //  สร้างคำสั่งซื้อ
            .addCase(createOrder.pending, (state) => {
                state.loading = true;
            })
            .addCase(createOrder.fulfilled, (state) => {
                state.loading = false;
                state.successMessage = 'บันทึกคำสั่งซื้อเรียบร้อย ✅';
            })
            .addCase(createOrder.rejected, (state) => {
                state.loading = false;
                state.successMessage = 'เกิดข้อผิดพลาดในการบันทึกคำสั่งซื้อ ❌';
            });
    },
});

//  export actions เพื่อใช้ใน component
export const { setSelectedModel, setSelectedColor } = productSlice.actions;

// export reducer เพื่อใช้ใน store
export default productSlice.reducer;