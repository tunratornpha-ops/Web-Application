//  นำเข้าเครื่องมือจาก Redux Toolkit
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../api/axiosConfig'; // ใช้ axios instance ที่ตั้ง baseURL '/api'

//  โครงสร้างของคำสั่งซื้อ (Order)
export interface Order {
  customerName: string;
  email: string;
  phone: string;
  address: string;
  items: Array<{
    name: string;
    color: string;
    storage: string;
    price: number;
    quantity: number;
  }>;
  totalPrice: number;
}

//  โครงสร้างของ state ที่ใช้ใน slice นี้
interface OrderState {
  loading: boolean;          // ระบุว่ากำลังโหลดอยู่ไหม
  success: boolean;          // ระบุว่าสั่งซื้อสำเร็จไหม
  error: string | null;      // เก็บข้อความ error
  successMessage: string | null; // ข้อความแสดงผลสำเร็จ
}

//  ค่าเริ่มต้นของ state
const initialState: OrderState = {
  loading: false,
  success: false,
  error: null,
  successMessage: null,
};

//  ฟังก์ชัน AsyncThunk สำหรับสร้างคำสั่งซื้อ (POST → /api/orders)
export const createOrder = createAsyncThunk('orders/createOrder', async (order: Order) => {
  const res = await api.post('/orders', order); // ส่งข้อมูล order ไป backend
  return res.data; // คืนค่าข้อมูลที่ backend ส่งกลับ
});

//  สร้าง Slice สำหรับคำสั่งซื้อ
const orderSlice = createSlice({
  name: 'orders', // ชื่อของ slice
  initialState,
  reducers: {
    // ฟังก์ชันรีเซ็ตค่า state หลังจากสั่งซื้อเสร็จหรือออกจากหน้า
    resetOrderState: (state) => {
      state.loading = false;
      state.success = false;
      state.error = null;
      state.successMessage = null;
    },
  },
  //  จัดการ state ตามสถานะของ AsyncThunk
  extraReducers: (builder) => {
    builder
      // เมื่อเริ่มส่งคำสั่งซื้อ
      .addCase(createOrder.pending, (state) => {
        state.loading = true;
        state.success = false;
        state.error = null;
        state.successMessage = null;
      })
      // เมื่อสั่งซื้อสำเร็จ
      .addCase(createOrder.fulfilled, (state, action) => {
        state.loading = false;
        state.success = true;
        state.successMessage = '✅ บันทึกคำสั่งซื้อเรียบร้อย';
        console.log('📦 Order created:', action.payload);
      })
      // เมื่อสั่งซื้อไม่สำเร็จ
      .addCase(createOrder.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'เกิดข้อผิดพลาดในการสั่งซื้อ ❌';
      });
  },
});

//  export action และ reducer
export const { resetOrderState } = orderSlice.actions;
export default orderSlice.reducer;