// นำเข้าเครื่องมือสร้าง store จาก Redux Toolkit
import { configureStore } from '@reduxjs/toolkit';

// นำเข้า reducers จากแต่ละ slice
import productReducer from './Productslice';
import cartReducer from './Cartslice';
import orderReducer from './Orderslice';

// ✅ รวม reducers ทั้งหมดเข้าเป็น store หลักของแอป
export const store = configureStore({
    reducer: {
        products: productReducer, // จัดการ state สินค้า
        cart: cartReducer,        // จัดการ state ตะกร้า
        orders: orderReducer,     // จัดการ state คำสั่งซื้อ
    },
});

// ✅ ประกาศ type ของ state ทั้งหมดใน store (ใช้กับ useSelector)
export type RootState = ReturnType<typeof store.getState>;

// ✅ ประกาศ type ของ dispatch (ใช้กับ useDispatch)
export type AppDispatch = typeof store.dispatch;