//  นำเข้าเครื่องมือจาก Redux Toolkit
import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

//  กำหนดโครงสร้างของสินค้าในตะกร้า (Cart Item)
interface CartItem {
  id: number;           // รหัสสินค้า
  name: string;         // ชื่อสินค้า
  price: number;        // ราคาสินค้า
  color: string;        // สีที่เลือก
  storage: string;      // ความจุที่เลือก
  quantity: number;     // จำนวนในตะกร้า
  image?: string;       // รูปภาพสินค้า (optional)
}

//  กำหนดโครงสร้าง state ของตะกร้าสินค้า
interface CartState {
  items: CartItem[];    // รายการสินค้าในตะกร้า
}

//  ค่าตั้งต้นของ state
const initialState: CartState = {
  items: [],
};

//  สร้าง slice สำหรับจัดการข้อมูลตะกร้าสินค้า
const cartSlice = createSlice({
  name: 'cart', // ชื่อ slice
  initialState,
  reducers: {
    //  เพิ่มสินค้าเข้าตะกร้า
    addToCart: (state, action: PayloadAction<CartItem>) => {
      //  ตรวจสอบว่าสินค้านี้ (id + color + storage) มีอยู่แล้วไหม
      const existingItem = state.items.find(
        (item) =>
          item.id === action.payload.id &&
          item.color === action.payload.color &&
          item.storage === action.payload.storage
      );

      if (existingItem) {
        //  ถ้ามีแล้ว → เพิ่มจำนวนขึ้น 1
        existingItem.quantity += 1;
      } else {
        //  ถ้ายังไม่มี → เพิ่มสินค้าใหม่เข้าตะกร้า
        state.items.push({ ...action.payload, quantity: 1 });
      }
    },

    //  ลบสินค้าออกจากตะกร้า (ตาม id)
    removeFromCart: (state, action: PayloadAction<number>) => {
      state.items = state.items.filter((item) => item.id !== action.payload);
    },

    //  ล้างตะกร้าทั้งหมด
    clearCart: (state) => {
      state.items = [];
    },
  },
});

//  export actions และ reducer เพื่อใช้งานใน components อื่นๆ
export const { addToCart, removeFromCart, clearCart } = cartSlice.actions;
export default cartSlice.reducer;