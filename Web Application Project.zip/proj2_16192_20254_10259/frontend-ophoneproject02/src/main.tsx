import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import { Provider } from 'react-redux';
import { store } from './store/Store';
import './index.css'; // ไฟล์ CSS หลัก (Tailwind / Custom Style)

//  จุดเริ่มต้นของแอป (root component)
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {/* Provider ใช้เชื่อม Redux Store เข้ากับ React ทั้งแอป */}
    <Provider store={store}>
      {/* โหลดหน้า App หลัก ซึ่งมี routing และ layout ทั้งหมด */}
      <App />
    </Provider>
  </React.StrictMode>,
);