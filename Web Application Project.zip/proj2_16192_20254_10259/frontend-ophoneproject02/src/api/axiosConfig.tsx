import axios from 'axios';

// ⚙️ สร้าง instance ของ Axios เพื่อใช้เรียก API ได้ง่ายขึ้น
const api = axios.create({
  baseURL: '/api', // prefix ของทุก request (เชื่อม backend ผ่าน proxy vite.config.ts)
  headers: {
    'Content-Type': 'application/json', // ให้ส่งข้อมูลแบบ JSON ทุกครั้ง
  },
});

export default api;