import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// 🧭 นำเข้าหน้า (Page) และ component ทั้งหมด
import Navbar from './components/Navbar';
import Home from './Page/Home';
import ProductDetail from './Page/Productdetail';
import Cart from './Page/Cart';
import Checkout from './Page/Checkout';
import OPhone from './Page/Ophone';
import OPhone17 from './Page/ophone17';
import OPhone17pro from './Page/ophone17pro';
import OPhone16pro from './Page/ophone16pro';
import OPhone16 from './Page/ophone16';
import OPhone16plus from './Page/ophone16plus';
import OPhone15 from './Page/ophone15';
import ListStock from './Page/Liststock';
import Login from './Page/Login';
import Register from './Page/Register';

const App: React.FC = () => {
  return (
    // 🌐 ใช้ BrowserRouter ควบคุมการเปลี่ยนหน้าแบบ Single Page App
    <Router>
      {/* 🔝 Navbar แสดงทุกหน้า */}
      <Navbar />

      {/* 📄 พื้นที่หลักของแต่ละหน้า */}
      <main className="p-4">
        <Routes>
          {/* 🏠 หน้าแรก */}
          <Route path="/" element={<Home />} />

          {/* 📱 หน้ารวมสินค้า */}
          <Route path="/ophone" element={<OPhone />} />

          {/* 🔍 หน้ารายละเอียดสินค้าแบบ dynamic (ตาม id) */}
          <Route path="/product/:id" element={<ProductDetail />} />

          {/* 🛒 หน้าตะกร้าสินค้า */}
          <Route path="/cart" element={<Cart />} />

          {/* 💳 หน้าชำระเงิน */}
          <Route path="/checkout" element={<Checkout />} />

          {/* 📱 หน้ารายละเอียดแต่ละรุ่น (static pages) */}
          <Route path="/ophone17" element={<OPhone17 />} />
          <Route path="/ophone17pro" element={<OPhone17pro />} />
          <Route path="/ophone16pro" element={<OPhone16pro />} />
          <Route path="/ophone16plus" element={<OPhone16plus />} />
          <Route path="/ophone16" element={<OPhone16 />} />
          <Route path="/ophone15" element={<OPhone15 />} />

          {/* 📦 หน้าแสดงสต็อกสินค้า (ดึงจาก MongoDB) */}
          <Route path="/Liststock" element={<ListStock />} />

          <Route path="/Login" element={<Login />} />
          <Route path="/Register" element={<Register />} />


        </Routes>
      </main>
    </Router>
  );
};

export default App;