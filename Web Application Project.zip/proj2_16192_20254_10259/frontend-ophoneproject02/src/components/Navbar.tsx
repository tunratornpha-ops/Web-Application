import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import type { RootState } from '../store/Store';

const Navbar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { items } = useSelector((state: RootState) => state.cart);

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(
    localStorage.getItem('isLoggedIn') === 'true'
  );

  const totalQty = items.reduce((sum, i) => sum + i.quantity, 0);

  const isActive = (path: string) =>
    location.pathname === path
      ? 'text-slate-900'
      : 'text-slate-600 hover:text-slate-900';

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);

    // ✅ แจ้ง event ออกจากระบบ
    window.dispatchEvent(new Event('loginStatusChanged'));

    navigate('/login');
  };

  useEffect(() => {
    const handleLoginStatusChange = () => {
      setIsLoggedIn(localStorage.getItem('isLoggedIn') === 'true');
    };

    // ✅ ฟัง event loginStatusChanged จากหน้า Login
    window.addEventListener('loginStatusChanged', handleLoginStatusChange);

    return () => {
      window.removeEventListener('loginStatusChanged', handleLoginStatusChange);
    };
  }, []);

  return (
    <nav className="sticky top-0 z-50 w-full">
      <div className="h-px w-full bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
      <div className="backdrop-blur-md bg-white/70 shadow-md ring-1 ring-white/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex h-14 items-center justify-between">
            {/* โลโก้ */}
            <div className="flex items-center gap-3">
              <Link to="/" className="inline-flex items-center gap-2">
                <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-slate-900 text-white text-sm font-bold shadow">
                  OP
                </span>
                <span className="text-lg font-semibold tracking-tight text-slate-900">
                  OPhoneShop
                </span>
              </Link>
            </div>

            {/* เมนู */}
            <div className="hidden md:flex items-center gap-6">
              <Link to="/" className={`text-sm font-medium ${isActive('/')}`}>
                Home
              </Link>

              <Link
                to="/ophone"
                className={`text-sm font-medium ${isActive('/ophone')}`}
              >
                OPhone
              </Link>

              <Link
                to="/Liststock"
                className={`text-sm font-medium ${isActive('/Liststock')}`}
              >
                ListStock
              </Link>
            </div>

            {/* Login / Logout + Cart */}
            <div className="flex items-center gap-4">
              {!isLoggedIn ? (
                <Link
                  to="/login"
                  className={`text-sm font-medium ${isActive('/login')}`}
                >
                  Login
                </Link>
              ) : (
                <button
                  onClick={handleLogout}
                  className="text-red-600 hover:underline font-semibold text-sm"
                >
                  Logout
                </button>
              )}

              {/* Cart */}
              <Link
                to="/cart"
                className="relative inline-flex items-center gap-2 rounded-full bg-slate-900 px-3 py-1.5 text-white text-sm shadow hover:bg-slate-800 transition"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="h-5 w-5"
                >
                  <path d="M7 4a1 1 0 0 0-1 1v2H3.5a1 1 0 1 0 0 2H5l1.25 8.254A3 3 0 0 0 9.223 20h5.554a3 3 0 0 0 2.973-2.746L19 9h1.5a1 1 0 1 0 0-2H18V5a1 1 0 1 0-2 0v2H8V5a1 1 0 0 0-1-1ZM8.277 18a1 1 0 0 1-.992-.874L6.12 9h11.76l-1.165 8.126A1 1 0 0 1 14.777 18H8.277Z" />
                </svg>
                <span>Cart</span>
                {totalQty > 0 && (
                  <span className="absolute -right-2 -top-2 min-w-[20px] rounded-full bg-white text-slate-900 text-xs font-semibold px-1.5 py-0.5 ring-2 ring-slate-900 shadow">
                    {totalQty}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>
      </div>
      <div className="h-px w-full bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
    </nav>
  );
};

export default Navbar;