import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../store/Cartslice';
import type { AppDispatch } from '../store/Store';

// 💰 ราคาตามความจุ
const priceByStorage: Record<string, number> = {
  '256GB': 22900,
  '512GB': 25900,
};

const OPhone16: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();

  // 🎨 state สำหรับเก็บสีและความจุที่เลือก
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedStorage, setSelectedStorage] = useState<string>('');

  // 🛒 เพิ่มสินค้าในตะกร้า
  const handleAddToCart = () => {
    // ถ้ายังไม่เลือกสีหรือความจุ → แจ้งเตือนก่อน
    if (!selectedColor || !selectedStorage) {
      alert('กรุณาเลือกสีและความจุก่อนสั่งซื้อ ❗');
      return;
    }

    const price = priceByStorage[selectedStorage] ?? 22900;
    const product = {
      id: 5,
      name: 'OPhone 16',
      price,
      color: selectedColor,
      storage: selectedStorage,
      quantity: 1,
      image: '/imagePRO/iPhone-16-Teal-removebg-preview.png', // ✅ เอา "public/" ออก
    };

    dispatch(addToCart(product));
    alert('✅ เพิ่มสินค้าไปยังตะกร้าแล้ว!');
  };

  return (
    <div className="bg-white min-h-screen text-gray-900">
      {/* ---------- ส่วนหัว ---------- */}
      <section className="text-center py-10">
        <h1 className="text-5xl font-bold mb-2">ซื้อ OPhone 16</h1>
        <p className="text-xl text-gray-600">เริ่มต้นที่ ฿22,900</p>
      </section>

      {/* ---------- ส่วนรูปสินค้า ---------- */}
      <section className="flex flex-col md:flex-row justify-center items-center gap-10 px-8 py-10 bg-gray-50 rounded-3xl max-w-7xl mx-auto">
        <img
          src="/imagePRO/iPhone-16-Teal-removebg-preview.png"
          alt="OPhone 16"
          className="w-[500px] rounded-2xl"
        />

        {/* ---------- ตัวเลือกสินค้า ---------- */}
        <div className="text-left">
          {/* 🔘 เลือกสี */}
          <h2 className="text-lg font-semibold text-gray-700 mb-2">สีที่คุณชื่นชอบ</h2>
          <div className="flex gap-3 mb-8">
            {[
              { name: 'Gold', color: '#eed77b' },
              { name: 'RoseGold', color: '#B76E79' },
              { name: 'Black', color: '#000000' },
              { name: 'Silver', color: '#C4C4C4' },
            ].map((c) => (
              <button
                key={c.name}
                onClick={() => setSelectedColor(c.name)}
                className={`w-10 h-10 rounded-full border-2 ${
                  selectedColor === c.name ? 'border-blue-600' : 'border-gray-300'
                }`}
                style={{ backgroundColor: c.color }}
                title={c.name}
              ></button>
            ))}
          </div>

          {/* 🔘 เลือกความจุ */}
          <h2 className="text-lg font-semibold text-gray-700 mb-2">ความจุที่คุณต้องการ</h2>
          <div className="flex flex-col gap-3">
            {/* 256GB */}
            <button
              onClick={() => setSelectedStorage('256GB')}
              className={`border rounded-xl px-6 py-3 text-left ${
                selectedStorage === '256GB'
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-500'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="text-lg font-medium">256GB</span>
                <span className="text-gray-600">เริ่มต้นที่ ฿22,900</span>
              </div>
            </button>

            {/* 512GB */}
            <button
              onClick={() => setSelectedStorage('512GB')}
              className={`border rounded-xl px-6 py-3 text-left ${
                selectedStorage === '512GB'
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-500'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className="text-lg font-medium">512GB</span>
                <span className="text-gray-600">เริ่มต้นที่ ฿25,900</span>
              </div>
            </button>
          </div>

          {/* 🔘 ปุ่มสั่งซื้อ */}
          <div className="mt-10">
            <p className="text-gray-700 mb-3">
              <strong>สี:</strong> {selectedColor || '—'} |{' '}
              <strong>ความจุ:</strong> {selectedStorage || '—'}
            </p>
            <button
              onClick={handleAddToCart}
              disabled={!selectedColor || !selectedStorage}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-full text-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              สั่งซื้อสินค้า
            </button>
          </div>

          {/* 🔙 ปุ่มย้อนกลับ */}
          <div className="mt-6 text-center">
            <Link to="/ophone" className="text-blue-600 hover:underline">
              ← กลับไปหน้ารวมสินค้า
            </Link>
          </div>
        </div>
      </section>

      {/* ---------- ส่วนท้าย ---------- */}
      <footer className="text-center text-gray-500 py-8 text-sm">
        © 2025 PhoneShop — Inspired by Apple
      </footer>
    </div>
  );
};

export default OPhone16;