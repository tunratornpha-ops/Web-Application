import React from "react";
import { Link } from "react-router-dom";

const Home: React.FC = () => {
  return (
    // 🔷 พื้นหลังเต็มหน้าจอ พร้อม gradient ไล่สีแนวตั้ง
    <section className="relative w-full h-screen overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-800 text-white">
      
      {/* 🌌 พื้นหลังเคลื่อนไหว (วงกลมเรืองแสง) */}
      <div className="absolute inset-0">
        <div className="absolute -top-20 -left-20 w-[700px] h-[700px] bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* 🧠 เนื้อหาหลัก (ชื่อสินค้า + ปุ่ม + รูป) */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
        
        {/* 🔤 ชื่อสินค้า */}
        <h1 className="text-6xl md:text-7xl font-extrabold mb-6 tracking-tight drop-shadow-lg">
          OPhone 17 Pro
        </h1>

        {/* 📄 คำบรรยาย */}
        <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl">
          สัมผัสพลังของ Vibranium — แข็งแกร่ง เบา และเหนือชั้นกว่าที่เคย  
          พร้อมชิป OFusion ใหม่ที่เร็วที่สุดเท่าที่เคยมีมา
        </p>

        {/* 🛒 ปุ่มไปหน้าซื้อ / สำรวจ */}
        <div className="flex gap-6">
          <Link
            to="/ophone17pro"
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
          >
            ซื้อเลย
          </Link>
          <Link
            to="/ophone"
            className="bg-transparent border border-white/50 hover:border-white px-8 py-3 rounded-full text-lg font-semibold text-white hover:bg-white/10 transition-all"
          >
            สำรวจสินค้า
          </Link>
        </div>

        {/* 📱 ภาพสินค้า */}
        <div className="mt-12">
          <img
            src="/imagePRO/iPhone_17_Pro_Max_Deep_Blue_01-square_medium-removebg-preview.png"
            alt="OPhone 17 Pro"
            className="w-[340px] md:w-[460px] drop-shadow-[0_15px_40px_rgba(0,0,0,0.6)] hover:scale-105 transition-transform duration-500"
          />
        </div>
      </div>

      {/* 🌫️ เงา fade ด้านล่างของหน้า */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-slate-950 to-transparent pointer-events-none" />
    </section>
  );
};

export default Home;