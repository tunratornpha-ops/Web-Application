import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom'; 
import { useDispatch, useSelector } from 'react-redux';
import type { RootState, AppDispatch } from '../store/Store';

// 🧩 import action จาก ProductSlice
import {
  fetchProductById,     // ดึงข้อมูลสินค้ารายตัวจาก backend
  setSelectedModel,      // เก็บชื่อรุ่นที่เลือก
  setSelectedColor,      // เก็บสีที่เลือก
  createOrder,           // สร้างคำสั่งซื้อ (mock)
} from '../store/Productslice';

const ProductDetail: React.FC = () => {
  // 🔗 ดึง id จาก URL เช่น /product/123
  const { id } = useParams<{ id: string }>();

  const dispatch = useDispatch<AppDispatch>();

  // 🎯 ดึง state ที่เกี่ยวข้องจาก Redux store
  const {
    items,
    selectedModel,
    selectedColor,
    loading,
    error,
    successMessage,
  } = useSelector((state: RootState) => state.products);

  // 🧠 โหลดข้อมูลสินค้าเมื่อเข้าหน้านี้ (fetch จาก MongoDB ผ่าน backend)
  useEffect(() => {
    if (id) dispatch(fetchProductById(id));
  }, [dispatch, id]);

  // 🛒 ฟังก์ชันสั่งซื้อสินค้า
  const handleOrder = () => {
    if (!items || !selectedModel || !selectedColor) return;

    // ✅ เตรียมข้อมูลสำหรับสร้างคำสั่งซื้อ (order)
    const orderData = {
      id: id || '',
      name: selectedModel,
      price: (Array.isArray(items) ? items[0]?.price : (items as any)?.price) || 0,
      color: selectedColor,
    };

    // 🧾 ส่งข้อมูลไป slice → backend
    dispatch(createOrder(orderData));
  };

  // 🔄 แสดงสถานะโหลด / error
  if (loading) return <p className="text-center py-10">กำลังโหลดข้อมูล...</p>;
  if (error) return <p className="text-center text-red-500 py-10">{error}</p>;
  if (!items) return <p className="text-center py-10">ไม่พบข้อมูลสินค้า</p>;

  // 📦 ถ้า items เป็น array → ดึงตัวแรกมาใช้
  const product = Array.isArray(items) ? items[0] : items;

  return (
    <div className="max-w-6xl mx-auto py-8">
      {/* 🏷️ ชื่อและราคาสินค้า */}
      <h1 className="text-3xl font-bold mb-3">{product.name}</h1>
      <p className="text-gray-500 mb-8">
        เริ่มต้นที่ ฿{product.price.toLocaleString()}
      </p>

      <div className="flex flex-col md:flex-row gap-10">
        {/* 🖼️ พื้นที่แสดงภาพสินค้า (ตอนนี้เป็น placeholder) */}
        <div className="flex-1 flex justify-center items-center bg-gray-100 rounded-2xl p-8">
          <div className="w-56 h-96 bg-gradient-to-b from-gray-200 to-gray-400 rounded-3xl" />
        </div>

        {/* 🎨 ตัวเลือกสินค้า */}
        <div className="flex-1">
          {/* 🔘 เลือกรุ่น */}
          <h2 className="text-xl font-semibold mb-3">เลือกรุ่น</h2>
          <div className="space-y-3">
            <button
              onClick={() => dispatch(setSelectedModel(product.name))}
              className={`block w-full text-left border p-3 rounded-lg ${
                selectedModel === product.name
                  ? 'border-blue-600 bg-blue-50'
                  : 'border-gray-300'
              }`}
            >
              <div className="flex justify-between">
                <span>{product.name}</span>
                <span>฿{product.price.toLocaleString()}</span>
              </div>
            </button>
          </div>

          {/* 🎨 เลือกสี */}
          <h2 className="text-xl font-semibold mt-6 mb-3">เลือกสี</h2>
          <div className="flex flex-wrap gap-3">
            {['Silver', 'Black', 'Gold', 'Blue'].map((color) => (
              <button
                key={color}
                onClick={() => dispatch(setSelectedColor(color))}
                className={`px-4 py-2 border rounded-full ${
                  selectedColor === color
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-300'
                }`}
              >
                {color}
              </button>
            ))}
          </div>

          {/* 🛍️ ปุ่มสั่งซื้อ */}
          <button
            onClick={handleOrder}
            className="mt-8 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
          >
            สั่งซื้อ
          </button>

          {/* ✅ ข้อความเมื่อสั่งซื้อสำเร็จ */}
          {successMessage && (
            <p className="mt-4 text-green-600 font-medium">{successMessage}</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;