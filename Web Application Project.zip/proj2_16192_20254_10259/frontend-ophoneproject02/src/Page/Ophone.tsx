import React, { useRef } from 'react';
import { Link } from 'react-router-dom';

const OPhone: React.FC = () => {
  // ✅ ข้อมูลสินค้าแต่ละรุ่น
  const products = [
    { id: 1, name: 'OPhone 17 Pro', link: '/ophone17pro', image: '/imagePRO/iPhone_17_Pro_Max_Deep_Blue_01-square_medium-removebg-preview.png', price: 'เริ่มต้น ฿48,900' },
    { id: 2, name: 'OPhone 17', link: '/ophone17', image: '/imagePRO/iphone-17-lavender-01.jpg-removebg-preview.png', price: 'เริ่มต้น ฿29,900' },
    { id: 3, name: 'OPhone 16 Pro', link: '/ophone16pro', image: '/imagePRO/iPhone_16_Pro_Max_Black_Titanium_1-removebg-preview.png', price: 'เริ่มต้น ฿33,900' },
    { id: 4, name: 'OPhone 16 Plus', link: '/ophone16plus', image: '/imagePRO/iPhone_16_Plus_Ultramarine_PDP_Image_Position_1a_Ultramarine_Color__TH-TH-square_medium-removebg-preview.png', price: 'เริ่มต้น ฿26,900' },
    { id: 5, name: 'OPhone 16', link: '/ophone16', image: '/imagePRO/iPhone-16-Teal-removebg-preview.png', price: 'เริ่มต้น ฿22,900' },
    { id: 6, name: 'OPhone 15', link: '/ophone15', image: '/imagePRO/iPhone_15_Blue-removebg-preview.png', price: 'เริ่มต้น ฿19,900' },
  ];

  // 🔁 ทำซ้ำอีกรอบเพื่อให้เลื่อนแบบไม่มีที่สิ้นสุด
  const loop = [...products, ...products];

  // ⚙️ ใช้ควบคุม marquee (เช่น หยุดเมื่อแตะ)
  const marqueeRef = useRef<HTMLDivElement | null>(null);
  const handleTouchStart = () => marqueeRef.current?.classList.add('paused');
  const handleTouchEnd = () => marqueeRef.current?.classList.remove('paused');

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-slate-50 via-white to-slate-100">
      
      {/* 🎨 พื้นหลังมีลาย grid บางๆ */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.08] bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0.55)_1px,transparent_1px)] [background-size:16px_16px]" />

      {/* 🧩 ส่วนหัวของหน้า */}
      <header className="relative z-10 px-6 sm:px-10 pt-10 flex flex-col gap-3">
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-slate-200 bg-white/70 backdrop-blur px-3 py-1 text-xs text-slate-600 shadow-sm">
          ใหม่ • สินค้าพร้อมส่ง
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">OPhone</h1>
        <p className="text-slate-600 max-w-xl">
          ค้นพบโทรศัพท์ที่ใช่สำหรับคุณ—ดีไซน์เหนือระดับ ประสิทธิภาพล้ำหน้า
        </p>
        <div className="mt-2">
          <Link
            to="/cart"
            className="inline-flex items-center gap-2 rounded-full bg-slate-900 text-white px-5 py-2.5 text-sm shadow hover:bg-slate-800 transition"
          >
            ไปที่ตะกร้า <span aria-hidden>→</span>
          </Link>
        </div>
      </header>

      {/* 🌀 ส่วนแถบเลื่อนสินค้าแบบ marquee */}
      <div className="absolute inset-0 flex items-center justify-start">
        <div
          ref={marqueeRef}
          className="marquee w-[200%] [--duration:28s]"
          onTouchStart={handleTouchStart} // หยุดเลื่อนตอนแตะ
          onTouchEnd={handleTouchEnd}     // กลับมาเลื่อนต่อ
        >
          {/* 🔹 ชุดหลัก */}
          <ul className="marquee__group pr-12 sm:pr-16">
            {loop.map((phone, i) => (
              <li key={`${phone.id}-${i}`}>
                <Link to={phone.link} className="group block rounded-3xl outline-none focus-visible:ring-2 focus-visible:ring-slate-300">
                  <div className="flex flex-col items-center">
                    
                    {/* 💎 การ์ดสินค้าแบบโปร่ง */}
                    <div className="relative flex items-end justify-center w-[150px] sm:w-[220px] h-[45vh] sm:h-[50vh] max-h-[350px] rounded-3xl bg-white/60 backdrop-blur-md shadow-[0_6px_40px_rgba(0,0,0,0.08)] ring-1 ring-white/60 overflow-hidden transition-transform group-hover:scale-[1.05]">
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/40" />
                      
                      {/* 🔖 ป้าย “ใหม่” สำหรับรุ่น 17 */}
                      {phone.name.includes('17') && (
                        <span className="absolute left-3 top-3 text-[10px] font-semibold text-orange-700 bg-orange-100/90 rounded-full px-2 py-1 shadow-sm">
                          ใหม่
                        </span>
                      )}

                      {/* 🖼️ รูปสินค้า */}
                      <img
                        src={phone.image}
                        alt={phone.name}
                        className="relative z-2 h-[82%] object-contain drop-shadow-sm transition-transform duration-300 group-hover:translate-y-[-2px]"
                        loading="lazy"
                      />

                      {/* ⚡ ปุ่ม “ดูรายละเอียด” / “ไปที่รุ่น” */}
                      <div className="card-quick absolute bottom-3 inset-x-3 flex gap-2">
                        <Link
                          to={phone.link}
                          className="flex-1 rounded-xl bg-slate-900/90 text-white text-xs px-3 py-2 text-center hover:bg-slate-900 transition"
                        >
                          ดูรายละเอียด
                        </Link>
                        <Link
                          to={phone.link}
                          className="rounded-xl bg-white/90 text-slate-900 text-xs px-3 py-2 text-center ring-1 ring-slate-200 hover:bg-white transition"
                        >
                          ไปที่รุ่น
                        </Link>
                      </div>
                    </div>

                    {/* 🏷️ ข้อความชื่อรุ่น + ราคา */}
                    <div className="mt-4 text-center">
                      <p className="text-base sm:text-lg font-semibold">{phone.name}</p>
                      <p className="text-xs sm:text-sm text-slate-500">{phone.price}</p>
                    </div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>

          {/* 🔁 ชุดซ้ำสำหรับ loop ต่อเนื่อง */}
          <ul className="marquee__group pr-12 sm:pr-16" aria-hidden="true">
            {loop.map((phone, i) => (
              <li key={`ghost-${phone.id}-${i}`}>
                <Link to={phone.link} className="group block rounded-3xl outline-none focus-visible:ring-2 focus-visible:ring-slate-300">
                  <div className="flex flex-col items-center">
                    <div className="relative flex items-end justify-center w-[200px] sm:w-[220px] h-[45vh] sm:h-[50vh] max-h-[350px] rounded-3xl bg-white/60 backdrop-blur-md shadow-[0_6px_40px_rgba(0,0,0,0.08)] ring-1 ring-white/60 overflow-hidden transition-transform group-hover:scale-[1.05]">
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/40" />
                      {phone.name.includes('17') && (
                        <span className="absolute left-3 top-3 text-[10px] font-semibold text-orange-700 bg-orange-100/90 rounded-full px-2 py-1 shadow-sm">
                          ใหม่
                        </span>
                      )}
                      <img
                        src={phone.image}
                        alt={phone.name}
                        className="relative z-10 h-[82%] object-contain drop-shadow-sm transition-transform duration-300 group-hover:translate-y-[-2px]"
                        loading="lazy"
                      />
                      <div className="card-quick absolute bottom-3 inset-x-3 flex gap-2">
                        <Link
                          to={phone.link}
                          className="flex-1 rounded-xl bg-slate-900/90 text-white text-xs px-3 py-2 text-center hover:bg-slate-900 transition"
                        >
                          ดูรายละเอียด
                        </Link>
                        <Link
                          to={phone.link}
                          className="rounded-xl bg-white/90 text-slate-900 text-xs px-3 py-2 text-center ring-1 ring-slate-200 hover:bg-white transition"
                        >
                          ไปที่รุ่น
                        </Link>
                      </div>
                    </div>
                    <div className="mt-4 text-center">
                      <p className="text-base sm:text-lg font-semibold">{phone.name}</p>
                      <p className="text-xs sm:text-sm text-slate-500">{phone.price}</p>
                    </div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default OPhone;