import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState, AppDispatch } from '../store/Store';
import { removeFromCart, clearCart } from '../store/Cartslice';
import { Link, useNavigate } from 'react-router-dom';

const Cart: React.FC = () => {
  // ✅ ใช้ hook ของ Redux
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();

  // ✅ ดึงข้อมูลสินค้าในตะกร้าจาก Redux store
  const { items } = useSelector((state: RootState) => state.cart);

  // 💰 คำนวณราคารวมทั้งหมด
  const totalPrice = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // 🧾 เมื่อกด "สั่งซื้อสินค้า"
  const handleCheckout = () => {
    if (items.length === 0) {
      alert('❗ ยังไม่มีสินค้าในตะกร้า');
      return;
    }

    // 💾 เก็บข้อมูลตะกร้าไว้ชั่วคราวใน localStorage
    localStorage.setItem('cartItems', JSON.stringify(items));
    localStorage.setItem('cartTotal', totalPrice.toString());

    // 🔁 ไปหน้าชำระเงิน
    navigate('/checkout');
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-6 bg-white">
      <h1 className="text-4xl font-semibold text-center mb-8">ตะกร้าสินค้า</h1>

      {/* ถ้าไม่มีสินค้า */}
      {items.length === 0 ? (
        <p className="text-center text-gray-500">ไม่มีสินค้าในตะกร้า</p>
      ) : (
        <>
          {/* แสดงรายการสินค้าในตะกร้า */}
          <ul className="divide-y divide-gray-200 mb-8">
            {items.map((item, index) => (
              <li key={index} className="flex items-center justify-between gap-4 py-4">
                
                {/* 🖼️ รูปสินค้า */}
                <div className="flex items-center gap-4">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 rounded-lg object-contain bg-gray-50 ring-1 ring-gray-100"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-lg bg-gray-100 ring-1 ring-gray-100 flex items-center justify-center text-gray-400 text-sm">
                      ไม่มีรูป
                    </div>
                  )}

                  {/* ℹ️ ข้อมูลสินค้า */}
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-gray-500">
                      สี: {item.color} | ความจุ: {item.storage} | จำนวน: {item.quantity}
                    </p>
                  </div>
                </div>

                {/* 💰 ราคาสินค้า + ปุ่มลบ */}
                <div className="text-right">
                  <p>฿{(item.price * item.quantity).toLocaleString()}</p>
                  <button
                    onClick={() => dispatch(removeFromCart(item.id))} // ❌ ลบสินค้าชิ้นนี้ออกจากตะกร้า
                    className="text-red-500 text-sm hover:underline"
                  >
                    ลบ
                  </button>
                </div>
              </li>
            ))}
          </ul>

          {/* 💵 ราคารวม + ปุ่มล้างตะกร้า */}
          <div className="flex justify-between items-center mb-6">
            <p className="text-xl font-semibold">
              ยอดรวม: ฿{totalPrice.toLocaleString()}
            </p>
            <button
              onClick={() => dispatch(clearCart())} // 🧹 ล้างตะกร้าทั้งหมด
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg"
            >
              ล้างตะกร้า
            </button>
          </div>

          {/* ✅ ปุ่มไป Checkout */}
          <div className="text-center">
            <Link to="/Checkout">
              <button
                onClick={handleCheckout}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full text-lg"
              >
                สั่งซื้อสินค้า
              </button>
            </Link>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;