import React, { useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import { createOrder } from '../store/Orderslice';
import { clearCart } from '../store/Cartslice';
import type { RootState, AppDispatch } from '../store/Store';

// 💰 ฟังก์ชันช่วยแปลงราคาให้อ่านง่าย เช่น ฿19,900
const formatPrice = (n: number) => `฿${n.toLocaleString()}`;

const Checkout: React.FC = () => {
    // ✅ ใช้ Redux dispatch และ React Router
    const dispatch = useDispatch<AppDispatch>();
    const navigate = useNavigate();

    // 🛒 ดึงข้อมูลสินค้าในตะกร้า
    const { items } = useSelector((state: RootState) => state.cart);

    // 🧾 ฟอร์มเก็บข้อมูลลูกค้า
    const [form, setForm] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
    });

    // 🔁 อัปเดตข้อมูลเมื่อพิมพ์ในช่อง input
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    // 💵 คำนวณยอดรวมและยอดชำระทั้งหมด (memoized)
    const cartSubtotal = useMemo(
        () => items.reduce((sum, i) => sum + i.price * i.quantity, 0),
        [items]
    );
    const shippingFee = 0; // 🚚 ค่าจัดส่ง (ตั้งค่าเพิ่มภายหลังได้)
    const grandTotal = cartSubtotal + shippingFee;

    // ✅ ตรวจสอบว่ากรอกข้อมูลครบหรือยัง
    const isFormValid =
        form.firstName.trim() &&
        form.lastName.trim() &&
        form.email.trim() &&
        form.phone.trim() &&
        form.address.trim();

    // 📦 เมื่อกดยืนยันการสั่งซื้อ
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid || items.length === 0) return;

        // 🧩 สร้าง payload ส่งไป backend
        const orderData = {
            customerName: `${form.firstName} ${form.lastName}`,
            email: form.email,
            phone: form.phone,
            address: form.address,
            items: items.map((i) => ({
                name: i.name,
                color: i.color,
                storage: i.storage,
                price: i.price,
                quantity: i.quantity,
            })),
            totalPrice: grandTotal,
        };

        try {
            console.log('📦 Order data:', orderData); 
            await dispatch(createOrder(orderData)).unwrap(); // ✅ ส่งข้อมูล order ไป backend
            alert('✅ ยืนยันการสั่งซื้อเรียบร้อยแล้ว!');
            dispatch(clearCart()); // 🧹 ล้างตะกร้า
            navigate('/ophone'); // 🔁 กลับไปหน้าสินค้า
        } catch (err) {
            console.error(err);
            alert('❌ เกิดข้อผิดพลาดในการสั่งซื้อ');
        }
    };

    // 🔙 ปุ่มย้อนกลับไปหน้าตะกร้า
    const handleGoBack = () => navigate('/cart');

    // ⚠️ ถ้าไม่มีสินค้าในตะกร้า
    if (items.length === 0) {
        return (
            <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg mt-10 text-center">
                <h1 className="text-3xl font-semibold mb-4">ตะกร้าของคุณว่างเปล่า</h1>
                <p className="text-gray-600 mb-6">โปรดเลือกสินค้าและเพิ่มลงตะกร้าก่อนทำการชำระเงิน</p>
                <Link to="/ophone" className="text-blue-600 hover:underline">
                    ← เลือกสินค้าต่อ
                </Link>
            </div>
        );
    }

    return (
        <div className="max-w-6xl mx-auto mt-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* 🧍‍♂️ ฟอร์มข้อมูลลูกค้า */}
            <div className="bg-white p-8 rounded-xl shadow-lg">
                <h1 className="text-3xl font-semibold text-center mb-8">กรอกข้อมูลลูกค้า</h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* 🔤 ชื่อและนามสกุล */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-gray-700 mb-2">ชื่อ</label>
                            <input
                                type="text"
                                name="firstName"
                                value={form.firstName}
                                onChange={handleChange}
                                className="w-full border border-gray-300 rounded-lg p-2"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 mb-2">นามสกุล</label>
                            <input
                                type="text"
                                name="lastName"
                                value={form.lastName}
                                onChange={handleChange}
                                className="w-full border border-gray-300 rounded-lg p-2"
                            />
                        </div>
                    </div>

                    {/* 📧 Email */}
                    <div>
                        <label className="block text-gray-700 mb-2">อีเมล</label>
                        <input
                            type="email"
                            name="email"
                            value={form.email}
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg p-2"
                        />
                    </div>

                    {/* 📞 เบอร์โทรศัพท์ */}
                    <div>
                        <label className="block text-gray-700 mb-2">เบอร์โทรศัพท์</label>
                        <input
                            type="tel"
                            name="phone"
                            value={form.phone}
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg p-2"
                        />
                    </div>

                    {/* 🏠 ที่อยู่ */}
                    <div>
                        <label className="block text-gray-700 mb-2">ที่อยู่จัดส่ง</label>
                        <textarea
                            name="address"
                            value={form.address}
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg p-2"
                            rows={3}
                        />
                    </div>

                    {/* 🔘 ปุ่มยืนยัน/ย้อนกลับ */}
                    <div className="flex justify-center gap-6 pt-2">
                        <button
                            type="button"
                            onClick={handleGoBack}
                            className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-3 rounded-full text-lg"
                        >
                            ย้อนกลับ
                        </button>

                        <button
                            type="submit"
                            disabled={!isFormValid || items.length === 0}
                            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-full text-lg"
                        >
                            ยืนยันการสั่งซื้อ
                        </button>
                    </div>
                </form>
            </div>

            {/* 📦 สรุปรายการสั่งซื้อ */}
            <div className="bg-white p-8 rounded-xl shadow-lg h-fit">
                <h2 className="text-2xl font-semibold mb-6">สรุปรายการสั่งซื้อ</h2>

                {/* 🔁 แสดงรายการสินค้า */}
                <ul className="divide-y divide-gray-200 mb-6">
                    {items.map((item, idx) => (
                        <li key={idx} className="py-4 flex justify-between gap-4">
                            <div>
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-gray-500">
                                    สี: {item.color} • ความจุ: {item.storage} • จำนวน: {item.quantity}
                                </p>
                            </div>
                            <div className="text-right">
                                <p className="font-medium">
                                    {formatPrice(item.price * item.quantity)}
                                </p>
                                <p className="text-xs text-gray-400">{formatPrice(item.price)} / ชิ้น</p>
                            </div>
                        </li>
                    ))}
                </ul>

                {/* 💰 รวมยอด */}
                <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-gray-600">ยอดรวมสินค้า</span>
                        <span className="font-medium">{formatPrice(cartSubtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-gray-600">ค่าจัดส่ง</span>
                        <span className="font-medium">{shippingFee === 0 ? 'ฟรี' : formatPrice(shippingFee)}</span>
                    </div>
                    <hr className="my-3" />
                    <div className="flex justify-between text-lg">
                        <span className="font-semibold">ยอดชำระทั้งหมด</span>
                        <span className="font-semibold">{formatPrice(grandTotal)}</span>
                    </div>
                </div>

                {/* 👤 แสดงข้อมูลลูกค้าแบบย่อ */}
                <div className="mt-6 bg-gray-50 rounded-lg p-4 text-sm">
                    <p className="font-medium mb-2">ข้อมูลผู้รับ (ตัวอย่างก่อนส่ง)</p>
                    <p>ชื่อ: {form.firstName || '—'} {form.lastName || ''}</p>
                    <p>อีเมล: {form.email || '—'}</p>
                    <p>เบอร์โทรศัพท์: {form.phone || '—'}</p>
                    <p>ที่อยู่: {form.address || '—'}</p>
                </div>
            </div>
        </div>
    );
};

export default Checkout;