import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // ✅ สมมุติ login สำเร็จ
    localStorage.setItem('isLoggedIn', 'true');
    window.dispatchEvent(new Event('loginStatusChanged'));
    navigate('/'); // กลับไปหน้าแรก
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <form
        onSubmit={handleLogin}
        className="bg-white p-8 rounded-2xl shadow-lg w-[400px]"
      >
        <h1 className="text-2xl font-semibold mb-6 text-center">Login</h1>
        <input
          type="email"
          placeholder="Email"
          className="border rounded-lg p-3 w-full mb-4"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="border rounded-lg p-3 w-full mb-6"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg"
        >
          เข้าสู่ระบบ
        </button>
        <p className="text-center text-sm text-gray-600">
          ยังไม่มีบัญชี? <a href="/register" className="text-blue-600 hover:underline">สมัครสมาชิก</a>
        </p>
      </form>
    </div>
  );
};

export default Login;