import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import type { RootState, AppDispatch } from '../store/Store';
import { fetchProducts } from '../store/Productslice';

const ListStock: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { items, loading, error } = useSelector((state: RootState) => state.products);

  // ✅ โหลดข้อมูลสินค้าจาก MongoDB ทันทีเมื่อเปิดหน้า
  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  // ⏳ แสดงสถานะระหว่างโหลดข้อมูล
  if (loading) return <p className="text-center py-10">กำลังโหลดข้อมูลสินค้า...</p>;
  // ❌ แสดงข้อความเมื่อเกิดข้อผิดพลาด
  if (error) return <p className="text-center text-red-500 py-10">{error}</p>;

  return (
    <div className="max-w-6xl mx-auto py-10 px-6 bg-white rounded-2xl shadow">
      {/* 🏷️ หัวข้อหน้า */}
      <h1 className="text-3xl font-bold mb-8 text-center">รายการสินค้าในสต็อก</h1>

      {/* 🧾 ตารางแสดงข้อมูลสินค้า */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-gray-200 text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="border border-gray-300 px-4 py-2 text-left">#</th>
              <th className="border border-gray-300 px-4 py-2 text-left">ชื่อสินค้า</th>
              <th className="border border-gray-300 px-4 py-2 text-left">สี</th>
              <th className="border border-gray-300 px-4 py-2 text-left">ความจุ</th>
              <th className="border border-gray-300 px-4 py-2 text-left">ราคา</th>
              <th className="border border-gray-300 px-4 py-2 text-left">จำนวนคงเหลือ</th>
              <th className="border border-gray-300 px-4 py-2 text-left">สถานะ</th>
            </tr>
          </thead>

          {/* 🔁 วนลูปแสดงข้อมูลสินค้าทั้งหมด */}
          <tbody>
            {items.map((product, index) => (
              <tr key={product.id || index} className="hover:bg-gray-50">
                {/* 🔢 ลำดับสินค้า */}
                <td className="border border-gray-300 px-4 py-2">{index + 1}</td>
                {/* 🏷️ ชื่อสินค้า */}
                <td className="border border-gray-300 px-4 py-2 font-medium">{product.name}</td>
                {/* 🎨 สีของสินค้า */}
                <td className="border border-gray-300 px-4 py-2">
                  {product.colorOptions?.join(', ') || '-'}
                </td>
                {/* 💾 ความจุสินค้า */}
                <td className="border border-gray-300 px-4 py-2">
                  {product.storageOptions?.join(', ') || '-'}
                </td>
                {/* 💰 ราคา */}
                <td className="border border-gray-300 px-4 py-2">
                  ฿{product.price?.toLocaleString()}
                </td>
                {/* 📦 จำนวนคงเหลือ */}
                <td className="border border-gray-300 px-4 py-2 text-center">
                  {product.quantity ?? '—'}
                </td>
                {/* 🔴🟢 สถานะสินค้า */}
                <td className="border border-gray-300 px-4 py-2 text-center">
                  {product.status === 'Out of Stock' ? (
                    // 🟥 หมดสินค้า
                    <span className="text-red-600 font-semibold bg-red-100 px-3 py-1 rounded-full">
                      หมดสินค้า
                    </span>
                  ) : (
                    // 🟩 มีสินค้า
                    <span className="text-green-600 font-semibold bg-green-100 px-3 py-1 rounded-full">
                      มีสินค้า
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ℹ️ ข้อความกำกับด้านล่าง */}
      <p className="text-center text-gray-500 mt-6">
        ข้อมูลนี้เชื่อมตรงจากฐานข้อมูล MongoDB
      </p>
    </div>
  );
};

export default ListStock;