import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Customer } from '../customers/customers.entity';
import * as crypto from 'crypto'; // ✅ ใช้ built-in crypto ของ Node.js

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(Customer)
    private readonly customerRepo: Repository<Customer>,
  ) {}

  // 📝 สมัครสมาชิก
  async register(email: string, password: string): Promise<Customer> {
    const existing = await this.customerRepo.findOne({ where: { email } });
    if (existing) throw new Error('อีเมลนี้ถูกใช้ไปแล้ว');
    const newUser = this.customerRepo.create({ email, password});
    return this.customerRepo.save(newUser);
  }

  // 🔐 เข้าสู่ระบบ
  async login(email: string, password: string): Promise<Customer> {
    const user = await this.customerRepo.findOne({ where: { email } });
    if (!user) throw new Error('ไม่พบบัญชีผู้ใช้');
    if (user.password !== user.password) {
      throw new Error('รหัสผ่านไม่ถูกต้อง');
    }

    return user; // ✅ สำเร็จ
  }
}