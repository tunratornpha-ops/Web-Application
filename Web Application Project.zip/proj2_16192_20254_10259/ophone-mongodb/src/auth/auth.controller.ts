import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from './auth.service';
import { Customer } from '../customers/customers.entity';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  // 🧾 สมัครสมาชิก
  @Post('register')
  register(@Body() body: { email: string; password: string }): Promise<Customer> {
    return this.authService.register(body.email, body.password);
  }

  // 🔑 ล็อกอิน
  @Post('login')
  login(@Body() body: { email: string; password: string }): Promise<Customer> {
    return this.authService.login(body.email, body.password);
  }
}