import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  // 🚀 สร้างแอป NestJS จาก AppModule
  const app = await NestFactory.create(AppModule);
  
  //  ใช้ ValidationPipe ทั่วทั้งระบบ
  // - whitelist: ตัดค่าที่ไม่ได้อยู่ใน DTO ออก
  // - transform: แปลงประเภทข้อมูลอัตโนมัติ
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // เปิดใช้งาน CORS เพื่อให้ frontend เรียก API ได้
  app.enableCors();

  // รันเซิร์ฟเวอร์บนพอร์ตที่กำหนด (ค่าเริ่มต้น 3000)
  await app.listen(process.env.PORT || 3000);
  console.log(`🚀 Server running on http://localhost:${process.env.PORT || 3000}`);
}
bootstrap();