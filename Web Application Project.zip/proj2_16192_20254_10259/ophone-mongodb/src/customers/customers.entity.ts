import { Entity, ObjectIdColumn, ObjectId, Column } from 'typeorm';

@Entity('customers') // 👈 จะสร้าง collection ชื่อ "customers"
export class Customer {
    @ObjectIdColumn()
    _id: ObjectId;

    @Column()
    email: string;

    @Column()
    password: string;

    @Column({ default: new Date() })
    createdAt: Date;
}