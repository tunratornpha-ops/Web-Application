import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ObjectId, MongoRepository } from 'typeorm';
import { Order } from './order.entity';
import { Product } from '../products/product.entity';

@Injectable()
export class OrdersService {
    constructor(
        // 🧾 Repository สำหรับตาราง Order (เก็บคำสั่งซื้อ)
        @InjectRepository(Order)
        private readonly orderRepo: Repository<Order>,

        // 📦 Repository สำหรับตาราง Product (เก็บข้อมูลสินค้า)
        @InjectRepository(Product)
        private readonly productRepo: MongoRepository<Product>,
    ) {}

    // 🛒 สร้างคำสั่งซื้อใหม่
    async create(order: Partial<Order>): Promise<Order> {
        // 🧱 สร้าง instance ของ order จากข้อมูลที่รับมา
        const newOrder = this.orderRepo.create(order);

        // 💾 บันทึกคำสั่งซื้อลงใน MongoDB
        const savedOrder = await this.orderRepo.save(newOrder);

        // ✅ ถ้ามีสินค้าใน order ให้เริ่มลด stock
        if (order.items && Array.isArray(order.items)) {
            for (const item of order.items) {
                // 🔍 ค้นหาสินค้าในฐานข้อมูลตามชื่อ สี และความจุ
                const product = await this.productRepo.findOne({
                    where: {
                        name: item.name,
                        colorOptions: item.color,
                        storageOptions: item.storage,
                    },
                });

                if (product) {
                    // 📉 คำนวณจำนวนใหม่หลังจากสั่งซื้อ
                    const oldQty = product.quantity ?? 0;
                    const newQty = Math.max(0, oldQty - (item.quantity ?? 1));

                    // ⚠️ ตั้งสถานะสินค้า (หมดหรือยังมี)
                    const status = newQty === 0 ? 'Out of Stock' : 'In Stock';

                    // 💾 อัปเดตจำนวนและสถานะใน MongoDB
                    await this.productRepo.update(
                        { _id: product._id },
                        { quantity: newQty, status },
                    );

                    console.log(`✅ ลดจำนวน: ${item.name} (${item.color} ${item.storage}) → ${newQty}`);
                } else {
                    console.warn(`⚠️ ไม่พบสินค้า: ${item.name} (${item.color} ${item.storage})`);
                }
            }
        }

        return savedOrder;
    }

    // 📦 ดึงคำสั่งซื้อทั้งหมด
    findAll() {
        return this.orderRepo.find();
    }

    // 🔍 ดึงคำสั่งซื้อเฉพาะ ID
    async findOne(id: string): Promise<Order> {
        const order = await this.orderRepo.findOneBy({ id: new ObjectId(id) });
        if (!order) throw new NotFoundException('ไม่พบข้อมูลคำสั่งซื้อ');
        return order;
    }

    // ❌ ลบคำสั่งซื้อ
    remove(id: string) {
        return this.orderRepo.delete({ id: new ObjectId(id) });
    }
}