import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrdersService } from './orders.service';
import { OrdersController } from './orders.controller';
import { Order } from './order.entity';
import { Product } from '../products/product.entity';

@Module({
  // 🧩 เชื่อม Entity เข้ากับ TypeORM เพื่อให้ OrdersService ใช้งานได้
  imports: [TypeOrmModule.forFeature([Order, Product])],

  // ⚙️ Register Service ที่ใช้จัดการ logic การสั่งซื้อ
  providers: [OrdersService],

  // 🌐 Register Controller สำหรับรับคำขอจาก frontend
  controllers: [OrdersController],
})
export class OrdersModule {}