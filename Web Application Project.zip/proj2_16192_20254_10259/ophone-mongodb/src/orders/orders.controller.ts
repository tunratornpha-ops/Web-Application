import { Controller, Get, Post, Delete, Param, Body } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { Order } from './order.entity';

// 🎯 กำหนดเส้นทางหลักของ API เป็น /orders
@Controller('orders')
export class OrdersController {
    constructor(private readonly ordersService: OrdersService) {}

    // 📦 ดึงข้อมูลคำสั่งซื้อทั้งหมด (GET /orders)
    @Get()
    findAll(): Promise<Order[]> {
        return this.ordersService.findAll();
    }

    // 🔍 ดึงข้อมูลคำสั่งซื้อเฉพาะ ID (GET /orders/:id)
    @Get(':id')
    findOne(@Param('id') id: string): Promise<Order> {
        return this.ordersService.findOne(id);
    }

    // 🧾 สร้างคำสั่งซื้อใหม่ (POST /orders)
    @Post()
    create(@Body() order: Partial<Order>): Promise<Order> {
        return this.ordersService.create(order);
    }

    // ❌ ลบคำสั่งซื้อ (DELETE /orders/:id)
    @Delete(':id')
    remove(@Param('id') id: string) {
        return this.ordersService.remove(id);
    }
}