import { Entity, ObjectIdColumn, ObjectId, Column } from 'typeorm';

// 🧱 Entity แทน collection "orders" ใน MongoDB
@Entity('orders')
export class Order {
    @ObjectIdColumn()
    id: ObjectId;

    @Column()
    customerName: string;

    @Column()
    email: string;

    @Column()
    phone: string;

    @Column()
    address: string;

    @Column('simple-json')
    items: Array<{
        name: string;
        color: string;
        storage: string;
        quantity: number;
    }>;    

    @Column()
    totalPrice: number;
}