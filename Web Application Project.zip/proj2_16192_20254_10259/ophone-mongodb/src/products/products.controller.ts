import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { ProductsService } from './products.service';
import { Product } from './product.entity';

// 🎯 กำหนดเส้นทางหลักของ API สำหรับสินค้า → /products
@Controller('products')
export class ProductsController {
    constructor(private readonly productsService: ProductsService) {}

    // 📦 ดึงข้อมูลสินค้าทั้งหมด (GET /products)
    @Get()
    findAll(): Promise<Product[]> {
        return this.productsService.findAll();
    }

    // 🔍 ดึงข้อมูลสินค้าตาม ID (GET /products/:id)
    @Get(':id')
    findOne(@Param('id') id: string): Promise<Product> {
        return this.productsService.findOne(id);
    }

    // 🧾 เพิ่มสินค้าใหม่ (POST /products)
    @Post()
    create(@Body() product: Partial<Product>): Promise<Product> {
        return this.productsService.create(product);
    }

    // ✏️ อัปเดตข้อมูลสินค้า (PUT /products/:id)
    @Put(':id')
    update(@Param('id') id: string, @Body() data: Partial<Product>) {
        return this.productsService.update(id, data);
    }

    // ❌ ลบสินค้า (DELETE /products/:id)
    @Delete(':id')
    remove(@Param('id') id: string) {
        return this.productsService.remove(id);
    }
}