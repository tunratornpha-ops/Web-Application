import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductsService } from './products.service';
import { ProductsController } from './products.controller';
import { Product } from './product.entity';

@Module({
  // 🧩 เชื่อม Entity (Product) เข้ากับ TypeORM เพื่อให้ service เข้าถึง MongoDB ได้
  imports: [TypeOrmModule.forFeature([Product])],

  // ⚙️ จัดการ logic ต่าง ๆ เกี่ยวกับสินค้า เช่น เพิ่ม, ลบ, อัปเดต, ดึงข้อมูล
  providers: [ProductsService],

  // 🌐 รับคำขอจากฝั่ง frontend (HTTP request) แล้วส่งต่อให้ service
  controllers: [ProductsController],
})
export class ProductsModule {}