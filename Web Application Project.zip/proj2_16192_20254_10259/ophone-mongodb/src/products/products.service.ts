import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ObjectId } from 'typeorm';
import { Product } from './product.entity';

@Injectable()
export class ProductsService {
    constructor(
        // 🧩 เชื่อมต่อ Repository ของ Entity `Product`
        @InjectRepository(Product)
        private readonly productRepo: Repository<Product>,
    ) { }

    // 📦 ดึงข้อมูลสินค้าทั้งหมดจาก MongoDB
    async findAll() {
        const products = await this.productRepo.find();

        // ✅ คำนวณสถานะสินค้าใหม่ทุกครั้งที่ดึงข้อมูล
        return products.map((p) => ({
            ...p,
            status: p.quantity > 0 ? 'In Stock' : 'Out of Stock',
        }));
    }

    // 🔍 ดึงข้อมูลสินค้าตาม id (ถ้าไม่เจอจะ throw error)
    async findOne(id: string): Promise<Product> {
        const product = await this.productRepo.findOneBy({ _id: new ObjectId(id) });
        if (!product) {
            throw new NotFoundException('ไม่พบข้อมูลสินค้า');
        }
        return product;
    }

    // 🧾 เพิ่มสินค้าใหม่เข้าไปในฐานข้อมูล
    create(product: Partial<Product>) {
        const newProduct = this.productRepo.create(product); // สร้าง instance ใหม่
        return this.productRepo.save(newProduct); // บันทึกลงฐานข้อมูล
    }

    // ✏️ อัปเดตข้อมูลสินค้า (เช่น ราคา, จำนวน, สถานะ)
    async update(id: string, data: Partial<Product>): Promise<Product> {
        const result = await this.productRepo.update({ _id: new ObjectId(id) }, data);

        // ❗ ถ้าไม่มีสินค้านั้น → แจ้งว่าไม่พบ
        if (result.affected === 0) {
            throw new NotFoundException('ไม่พบสินค้าที่ต้องการแก้ไข');
        }

        // ✅ คืนค่าข้อมูลสินค้าหลังอัปเดตสำเร็จ
        return this.findOne(id);
    }

    // ❌ ลบสินค้าออกจากฐานข้อมูล
    async remove(id: string) {
        const result = await this.productRepo.delete({ _id: new ObjectId(id) });

        // ❗ ถ้าไม่มีสินค้านั้น → แจ้งว่าไม่พบ
        if (result.affected === 0) {
            throw new NotFoundException('ไม่พบสินค้าที่ต้องการลบ');
        }

        // ✅ ส่งข้อความกลับไปยืนยันการลบ
        return { message: 'ลบสินค้าเรียบร้อยแล้ว ✅' };
    }
}