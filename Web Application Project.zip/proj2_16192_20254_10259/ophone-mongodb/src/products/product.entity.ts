import { Entity, ObjectIdColumn, ObjectId, Column } from 'typeorm';


// 🧱 กำหนดให้คลาสนี้แทน Collection 'products' ใน MongoDB
@Entity('products')
export class Product {
  @ObjectIdColumn()
  _id: ObjectId;

  @Column()
  name: string;

  @Column()
  price: number;

  @Column()
  colorOptions: string[];

  @Column('simple-array')
  storageOptions: string[];

  @Column()
  quantity: number;

  @Column({ default: 'In Stock' })
  status: string;
}