import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ProductsModule } from './products/products.module';
import { OrdersModule } from './orders/orders.module';
import { AuthModule } from './auth/auth.module';
import { Customer } from './customers/customers.entity';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),

    // ✅ ใช้ TypeORM เชื่อม MongoDB
    TypeOrmModule.forRoot({
      type: 'mongodb',              // ใช้ MongoDB
      host: process.env.DB_HOST || 'localhost',  // โฮสต์จาก .env
      port: parseInt(process.env.DB_PORT || '27017', 10),  // พอร์ตจาก .env
      database: process.env.DB_NAME ?? 'ophone', // ชื่อฐานข้อมูล      
      autoLoadEntities: true,        // โหลด entity อัตโนมัติ
      synchronize: false,           // ❌ ไม่ sync schema อัตโนมัติ (ปลอดภัยกว่า)

    }),

    ProductsModule,
    OrdersModule,
    AuthModule,
  ],
})
export class AppModule { }